/**
 * USER DEMO FX CANDLES API
 * GET /api/demo-fx/candles?pair_id=X&tf=1m
 *
 * Returns ALL candles for the pair regardless of session_id.
 * This gives continuous chart history — background candles flow
 * seamlessly into session candles and back.
 */
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function sb() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const pairId = searchParams.get('pair_id');
  const tf = searchParams.get('tf') || '1m';
  const limit = Math.min(Number(searchParams.get('limit') || 500), 2000);

  if (!pairId) return NextResponse.json({ error: 'pair_id required' }, { status: 400 });

  const supabase = sb();

  // Fetch ALL candles for this pair+timeframe — no session filter.
  // Background candles (session_id=null) and session candles all appear together
  // giving one continuous chart history.
  const { data, error } = await supabase
    .from('demo_fx_candles')
    .select('bucket_start, open, high, low, close, tick_count')
    .eq('pair_id', pairId)
    .eq('timeframe', tf)
    .order('bucket_start', { ascending: true })
    .limit(limit);

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  // Deduplicate by bucket_start (keep latest if overlap between session and background)
  const byTime = new Map<number, any>();
  for (const c of (data || [])) {
    const time = Math.floor(new Date(c.bucket_start).getTime() / 1000);
    if (time > 0 && Number(c.open) > 0) {
      byTime.set(time, {
        time,
        open: Number(c.open),
        high: Number(c.high),
        low: Number(c.low),
        close: Number(c.close),
      });
    }
  }

  const candles = Array.from(byTime.values()).sort((a, b) => a.time - b.time);

  return NextResponse.json({ candles, tf, pair_id: pairId });
}
