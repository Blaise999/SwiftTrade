/**
 * DEMO FX AUTO-TICK CRON
 * GET /api/demo-fx/cron
 *
 * Call this every 60 seconds from an external cron service (Vercel Cron, UptimeRobot, etc).
 * It ticks ALL active rare pairs that don't have a running session,
 * building candles 24/7 even when no users or admin are online.
 *
 * Optional: Add ?key=YOUR_SECRET to protect it.
 */
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function sb() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}

export async function GET(req: NextRequest) {
  // Optional auth — set CRON_SECRET env var to protect this endpoint
  const cronSecret = process.env.CRON_SECRET;
  if (cronSecret) {
    const { searchParams } = new URL(req.url);
    const key = searchParams.get('key') || req.headers.get('x-cron-key');
    if (key !== cronSecret) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
  }

  const supabase = sb();
  const now = new Date().toISOString();
  const results: any[] = [];

  // Get all active pairs without running sessions
  const { data: pairs } = await supabase
    .from('demo_fx_pairs')
    .select('id, current_bid, current_ask, seq, active_session_id, price_updated_at')
    .eq('is_active', true);

  if (!pairs || pairs.length === 0) {
    return NextResponse.json({ tick: true, results: [], msg: 'No active pairs' });
  }

  const { getNextTickFromPlanner } = await import('@/lib/demo-fx/candle-planner');
  const { appendDemoTickAndCandles, repriceOpenDemoTradesForPair } = await import('@/lib/demo-fx/reprice-helpers');

  for (const p of pairs) {
    if (p.active_session_id) continue; // session-tick handles these

    const bid = Number(p.current_bid);
    const ask = Number(p.current_ask);
    if (bid <= 0) continue;

    // Skip if ticked recently (within 50s)
    const lastUpdate = p.price_updated_at ? new Date(p.price_updated_at).getTime() : 0;
    if (Date.now() - lastUpdate < 50000) continue;

    const prevMid = (bid + ask) / 2;
    const seq = (Number(p.seq) || 0) + 1;

    try {
      const tick = getNextTickFromPlanner(
        'cron', p.id, 'range', 0.5, prevMid,
        0.0004, prevMid, prevMid, seq,
      );

      const realSpread = Math.max(ask - bid, prevMid * 0.00008);
      const newBid = Number((tick.mid - realSpread / 2).toFixed(6));
      const newAsk = Number((tick.mid + realSpread / 2).toFixed(6));

      await supabase.from('demo_fx_pairs').update({
        current_bid: newBid, current_ask: newAsk,
        seq, price_updated_at: now,
      }).eq('id', p.id);

      await supabase.from('demo_fx_ticks').insert({
        pair_id: p.id, session_id: null,
        bid: newBid, ask: newAsk, mid: tick.mid,
        source: 'system', seq, ts: now,
      });

      await appendDemoTickAndCandles(supabase, p.id, null, newBid, newAsk, seq, 'system');
      await repriceOpenDemoTradesForPair(supabase, p.id, newBid, newAsk);

      results.push({ pair_id: p.id, seq, bid: tick.bid, ask: tick.ask });
    } catch (e: any) {
      results.push({ pair_id: p.id, error: e?.message });
    }
  }

  return NextResponse.json({ tick: true, results, count: results.length });
}
