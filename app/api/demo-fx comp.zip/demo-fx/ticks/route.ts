/**
 * USER DEMO FX TICKS API
 * GET /api/demo-fx/ticks?pair_id=X&since_seq=N
 *
 * SELF-TICKING: If the pair has no active session AND hasn't been ticked
 * in 55+ seconds, this endpoint generates a background tick automatically.
 * Candles build 24/7 from user traffic alone. No admin needs to be online.
 */
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function sb() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const pairId = searchParams.get('pair_id');
  const sinceSeq = Number(searchParams.get('since_seq') || 0);

  if (!pairId) return NextResponse.json({ error: 'pair_id required' }, { status: 400 });

  const supabase = sb();

  const { data: pair } = await supabase
    .from('demo_fx_pairs')
    .select('id, symbol, current_bid, current_ask, mode, active_session_id, seq, price_updated_at, pip_size, spread')
    .eq('id', pairId)
    .maybeSingle();

  if (!pair) return NextResponse.json({ error: 'Pair not found' }, { status: 404 });

  // ─── AUTO-TICK if stale ───────────────────────────────────────────────
  const lastUpdate = pair.price_updated_at ? new Date(pair.price_updated_at).getTime() : 0;
  const staleMs = Date.now() - lastUpdate;
  const hasSession = !!pair.active_session_id;
  const bid = Number(pair.current_bid);
  const ask = Number(pair.current_ask);

  if (!hasSession && bid > 0 && staleMs > 55000) {
    try {
      const { getNextTickFromPlanner } = await import('@/lib/demo-fx/candle-planner');
      const { appendDemoTickAndCandles, repriceOpenDemoTradesForPair } = await import('@/lib/demo-fx/reprice-helpers');

      const prevMid = (bid + ask) / 2;
      const seq = (Number(pair.seq) || 0) + 1;
      const now = new Date().toISOString();

      const tick = getNextTickFromPlanner(
        'bg', pairId, 'range', 0.5, prevMid,
        0.0004, prevMid, prevMid, seq,
      );

      // Use pair's actual spread, not planner's tiny one
      const realSpread = Math.max(ask - bid, prevMid * 0.00008);
      const newBid = Number((tick.mid - realSpread / 2).toFixed(6));
      const newAsk = Number((tick.mid + realSpread / 2).toFixed(6));

      await supabase.from('demo_fx_pairs').update({
        current_bid: newBid, current_ask: newAsk,
        seq, price_updated_at: now,
      }).eq('id', pairId);

      await supabase.from('demo_fx_ticks').insert({
        pair_id: pairId, session_id: null,
        bid: newBid, ask: newAsk, mid: tick.mid,
        source: 'system', seq, ts: now,
      });

      await appendDemoTickAndCandles(supabase, pairId, null, newBid, newAsk, seq, 'system');
      await repriceOpenDemoTradesForPair(supabase, pairId, newBid, newAsk);

      pair.current_bid = newBid;
      pair.current_ask = newAsk;
      pair.seq = seq;
      pair.price_updated_at = now;
    } catch {}
  }

  // ─── Session info ─────────────────────────────────────────────────────
  let session: any = null;
  if (pair.active_session_id) {
    const { data: s } = await supabase
      .from('demo_fx_sessions')
      .select('id, session_type, status, duration_ms, elapsed_ms, started_at, tick_seq, student_instructions, lesson_title')
      .eq('id', pair.active_session_id)
      .maybeSingle();
    session = s;
  }

  // ─── Fetch ticks ──────────────────────────────────────────────────────
  let ticks: any[] = [];
  if (sinceSeq >= 0) {
    let tickQuery = supabase
      .from('demo_fx_ticks')
      .select('bid, ask, mid, seq, ts')
      .eq('pair_id', pairId)
      .gt('seq', sinceSeq)
      .order('seq', { ascending: true })
      .limit(200);

    if (pair.active_session_id) {
      tickQuery = tickQuery.eq('session_id', pair.active_session_id);
    }

    const { data: t } = await tickQuery;
    ticks = t || [];
  }

  return NextResponse.json({
    pair: {
      id: pair.id,
      symbol: pair.symbol,
      bid: Number(pair.current_bid),
      ask: Number(pair.current_ask),
      mid: (Number(pair.current_bid) + Number(pair.current_ask)) / 2,
      mode: pair.mode,
      session_id: pair.active_session_id,
      seq: pair.seq,
      pip_size: pair.pip_size,
      spread: pair.spread,
      updated_at: pair.price_updated_at,
    },
    session,
    ticks,
  });
}
